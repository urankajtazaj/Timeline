<?php


class Upvoter extends User
{

}